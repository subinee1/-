package com.gudi.board.dao;

public interface MapDAO {

}
