package com.gudi.board.dto;

public class MapDTO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
