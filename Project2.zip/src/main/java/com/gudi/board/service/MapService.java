package com.gudi.board.service;

import org.springframework.stereotype.Service;

@Service
public class MapService {

	
}
