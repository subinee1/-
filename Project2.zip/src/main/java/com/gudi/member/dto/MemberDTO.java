package com.gudi.member.dto;

public class MemberDTO {

}
