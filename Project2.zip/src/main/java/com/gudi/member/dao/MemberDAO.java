package com.gudi.member.dao;

public interface MemberDAO {

}
